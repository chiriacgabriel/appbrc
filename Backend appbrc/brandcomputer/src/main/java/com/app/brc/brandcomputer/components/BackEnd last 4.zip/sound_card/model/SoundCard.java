package com.app.brc.brandcomputer.components.sound_card.model;

import com.app.brc.brandcomputer.components.storage.model.GenerateProductCodeStorage;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "soundCard")
public class SoundCard {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    @JoinColumn(name = "productCode_id")
    private GenerateProductCodeSoundCard generateProductCodeSoundCard;

    private String serialNumber;
    private String manufacturer;
    private String model;

    private Double priceIn;
    private String productInformation;
    private String state;
    private String category;

    private LocalDateTime soldAt;
    private String soldBy;
    private boolean sold;

    @CreationTimestamp
    private LocalDateTime createdDate;
    private String createdBy;

    @UpdateTimestamp
    private LocalDateTime lastUpdated;
    private String updatedBy;
}
