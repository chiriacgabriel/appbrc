package com.app.brc.brandcomputer.components.processor.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Entity
@Table(name = "generateProductCodeProcessor")
public class GenerateProductCodeProcessor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String productCode;
    private String productName;
    private LocalDate createdDate;

    @OneToMany(mappedBy = "generateProductCodeProcessor")
    @JsonIgnore
    private List<Processor> processorList = new ArrayList<>();
}
