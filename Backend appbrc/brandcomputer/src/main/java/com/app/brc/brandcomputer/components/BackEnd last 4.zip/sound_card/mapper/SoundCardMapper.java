package com.app.brc.brandcomputer.components.sound_card.mapper;

import com.app.brc.brandcomputer.components.sound_card.dto.SoundCardDTO;
import com.app.brc.brandcomputer.components.sound_card.model.SoundCard;
import com.app.brc.brandcomputer.components.sound_card.repository.SoundCardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.Optional;

@Service
public class SoundCardMapper {

    private SoundCardRepository soundCardRepository;

    @Autowired
    public SoundCardMapper(SoundCardRepository soundCardRepository) {
        this.soundCardRepository = soundCardRepository;
    }

    public SoundCard map(SoundCardDTO soundCardDTO) {
        return SoundCard.builder()
                .generateProductCodeSoundCard(soundCardDTO.getGenerateProductCodeSoundCard())
                .serialNumber(soundCardDTO.getSerialNumber())
                .manufacturer(soundCardDTO.getManufacturer())
                .model(soundCardDTO.getModel())
                .priceIn(soundCardDTO.getPriceIn())
                .productInformation(soundCardDTO.getProductInformation())
                .state(soundCardDTO.getState())
                .category(soundCardDTO.getCategory())
                .soldAt(soundCardDTO.getSoldAt())
                .soldBy(soundCardDTO.getSoldBy())
                .sold(soundCardDTO.isSold())
                .createdDate(soundCardDTO.getCreatedDate())
                .createdBy(soundCardDTO.getCreatedBy())
                .lastUpdated(soundCardDTO.getLastUpdated())
                .updatedBy(soundCardDTO.getUpdatedBy())
                .build();
    }

    public SoundCardDTO map(SoundCard soundCard){
        return SoundCardDTO.builder()
                .id(soundCard.getId())
                .generateProductCodeSoundCard(soundCard.getGenerateProductCodeSoundCard())
                .serialNumber(soundCard.getSerialNumber())
                .manufacturer(soundCard.getManufacturer())
                .model(soundCard.getModel())
                .priceIn(soundCard.getPriceIn())
                .productInformation(soundCard.getProductInformation())
                .state(soundCard.getState())
                .category(soundCard.getCategory())
                .soldAt(soundCard.getSoldAt())
                .soldBy(soundCard.getSoldBy())
                .sold(soundCard.isSold())
                .createdDate(soundCard.getCreatedDate())
                .createdBy(soundCard.getCreatedBy())
                .lastUpdated(soundCard.getLastUpdated())
                .updatedBy(soundCard.getUpdatedBy())
                .build();
    }

    public void set(SoundCardDTO soundCardDTO, int id){
        Optional<SoundCard> optional = soundCardRepository.findById(id);

        if (!optional.isPresent()){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Sound card not found !");
        }

        SoundCard dbSoundCard = optional.get();

        dbSoundCard.setGenerateProductCodeSoundCard(soundCardDTO.getGenerateProductCodeSoundCard());
        dbSoundCard.setSerialNumber(soundCardDTO.getSerialNumber());
        dbSoundCard.setManufacturer(soundCardDTO.getManufacturer());
        dbSoundCard.setModel(soundCardDTO.getModel());
        dbSoundCard.setPriceIn(soundCardDTO.getPriceIn());
        dbSoundCard.setProductInformation(soundCardDTO.getProductInformation());
        dbSoundCard.setState(soundCardDTO.getState());

        dbSoundCard.setUpdatedBy(soundCardDTO.getUpdatedBy());

        soundCardRepository.save(dbSoundCard);
    }
}
