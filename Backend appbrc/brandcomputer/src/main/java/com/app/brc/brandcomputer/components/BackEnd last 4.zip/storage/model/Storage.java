package com.app.brc.brandcomputer.components.storage.model;

import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Entity
@Table(name = "storage")
public class Storage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    @JoinColumn(name = "productCode_id")
    private GenerateProductCodeStorage generateProductCodeStorage;

    private String serialNumber;
    private String manufacturer;

    private String model;
    private String type;
    private String form;
    private int capacity;
    private int rpm;

    private Double priceIn;
    private String productInformation;
    private String state;
    private String category;

    private LocalDateTime soldAt;
    private String soldBy;
    private boolean sold;

    @CreationTimestamp
    private LocalDateTime createdDate;
    private String createdBy;

    @UpdateTimestamp
    private LocalDateTime lastUpdated;
    private String updatedBy;

}
