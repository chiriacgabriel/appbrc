package com.app.brc.brandcomputer.components.broken;

import com.app.brc.brandcomputer.login.payload.response.MessageResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
@RequestMapping(value = "/api/broken", produces = "application/json")
public class BrokenRestController {

    private BrokenService brokenService;

    public BrokenRestController(BrokenService brokenService) {
        this.brokenService = brokenService;
    }

    @GetMapping("/{category}")
    public ResponseEntity<?> getAllBroken(@PathVariable String category,
                                          @RequestParam int page,
                                          @RequestParam int size){
        switch (category) {
            case "Case":
                return ResponseEntity.ok(brokenService.getAllCases(page, size));
            case "CpuCooler":
                return ResponseEntity.ok(brokenService.getAllCpuCoolers(page, size));
            case "FanCase":
                return ResponseEntity.ok(brokenService.getAllFanCases(page, size));
            case "MemoryRAM":
                return ResponseEntity.ok(brokenService.getAllMemoryRAMs(page, size));
            case "Motherboard":
                return ResponseEntity.ok(brokenService.getAllMotherboards(page, size));
            case "OpticalUnit":
                return ResponseEntity.ok(brokenService.getAllOpticalUnits(page, size));
            case "PowerSource":
                return ResponseEntity.ok(brokenService.getAllPowerSources(page, size));
            case "Processor":
                return ResponseEntity.ok(brokenService.getAllProcessors(page, size));
            case "SoundCard":
                return ResponseEntity.ok(brokenService.getAllSoundCards(page, size));
            case "Storage":
                return ResponseEntity.ok(brokenService.getAllStorages(page, size));
            case "VideoCard":
                return ResponseEntity.ok(brokenService.getAllVideoCards(page, size));
            case "All":
                return ResponseEntity.ok(brokenService.all(page, size));
            default:
                return ResponseEntity.badRequest().body(new MessageResponse("No category selected !"));
        }
    }


}
